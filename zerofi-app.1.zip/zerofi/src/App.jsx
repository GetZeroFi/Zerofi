// ── Zerofi App Root ───────────────────────────────────────────────────────────
import { useState, useEffect } from 'react';
import { load, save, clearAll, KEYS } from './utils/storage';
import { getTheme } from './utils/theme';
import { isSupabaseEnabled } from './utils/supabase';
import { useAuthProvider, AuthContext } from './hooks/useAuth';
import { isBetaUnlocked } from './utils/betaCode';
import NovaOnboarding from './components/NovaOnboarding';
import Auth from './pages/Auth';
import BetaGate from './pages/BetaGate';

// Lazy page loader
function Lazy({ loader, props }) {
  const [Comp, setComp] = useState(null);
  useEffect(() => { loader().then(C => setComp(() => C)); }, []);
  if (!Comp) return (
    <div style={{ minHeight:'100vh', background:'#080c14', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'monospace', color:'#5a7094', fontSize:13 }}>
      Loading…
    </div>
  );
  return <Comp {...props} />;
}

export default function App() {
  const auth = useAuthProvider();

  const [config,    setConfig]    = useState(null);
  const [editing,   setEditing]   = useState(false);
  const [useWizard, setUseWizard] = useState(false);
  const [betaOk,    setBetaOk]    = useState(isBetaUnlocked());
  const [pricingOpen, setPricingOpen] = useState(false);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    if (auth.loading) return;
    const saved = load(KEYS.config);
    if (saved) setConfig(saved);
    setLoading(false);
  }, [auth.loading]);

  const handleAuth = async (mode, { email, password, name } = {}) => {
    if (!isSupabaseEnabled) return { error:{ message:'Auth not configured — running in local mode.' } };
    if (mode === 'signin')  return auth.signIn(email, password);
    if (mode === 'signup')  return auth.signUp(email, password, name);
    if (mode === 'google')  return auth.signInWithGoogle();
    if (mode === 'apple')   return auth.signInWithApple();
    if (mode === 'reset') {
      const { error } = await auth.resetPassword(email);
      return error ? { error } : { message: 'Check your email for a reset link.' };
    }
  };

  const handleComplete = (cfg) => {
    if (!cfg) { setEditing(false); return; }
    save(KEYS.config, cfg);
    setConfig(cfg);
    setEditing(false);
    setUseWizard(false);
  };

  const handleReset = () => {
    if (!window.confirm('⚠️ Reset everything? All your Zerofi data will be permanently deleted.')) return;
    clearAll();
    if (isSupabaseEnabled && auth.user) auth.signOut();
    setConfig(null); setEditing(false); setUseWizard(false);
  };

  // Loading screen
  if (loading || auth.loading) return (
    <div style={{ minHeight:'100vh', background:'#080c14', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:16 }}>
      <div style={{ fontSize:38, fontFamily:'Georgia,serif', fontWeight:900, color:'#e8f0fe', letterSpacing:'-0.03em' }}>
        Zero<span style={{ color:'#3b82f6' }}>fi</span>
      </div>
      <div style={{ fontSize:11, color:'#5a7094', fontFamily:'monospace', letterSpacing:'0.1em' }}>LOADING…</div>
    </div>
  );

  return (
    <AuthContext.Provider value={auth}>
      {/* 1. Beta gate — first wall */}
      {!betaOk && <BetaGate onUnlock={() => setBetaOk(true)} />}

      {/* 2. Auth gate — only when Supabase is configured */}
      {betaOk && isSupabaseEnabled && !auth.user && (
        <Auth onAuth={handleAuth} isSupabaseEnabled={isSupabaseEnabled} />
      )}

      {/* 3. Nova onboarding — new users with no config */}
      {betaOk && (!isSupabaseEnabled || auth.user) && !config && !useWizard && (
        <NovaOnboarding onComplete={handleComplete} onUseWizard={() => setUseWizard(true)} />
      )}

      {/* 4. Manual wizard — fallback or edit mode */}
      {betaOk && (!isSupabaseEnabled || auth.user) && !config && useWizard && (
        <Lazy loader={() => import('./pages/Wizard').then(m => m.default)}
              props={{ onComplete: handleComplete }} />
      )}
      {betaOk && (!isSupabaseEnabled || auth.user) && config && editing && useWizard && (
        <Lazy loader={() => import('./pages/Wizard').then(m => m.default)}
              props={{ onComplete: handleComplete, initialConfig: config }} />
      )}

      {/* 5. Main dashboard */}
      {betaOk && (!isSupabaseEnabled || auth.user) && config && !(editing && useWizard) && (
        <Lazy loader={() => import('./pages/Dashboard').then(m => m.default)}
              props={{ config, onEdit: () => { setEditing(true); setUseWizard(true); }, onReset: handleReset }} />
      )}
    </AuthContext.Provider>
  );
}
