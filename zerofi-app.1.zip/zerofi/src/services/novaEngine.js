// ── Nova Insights Engine ──────────────────────────────────────────────────────
// Generates actionable, personalized financial insights from user data.
// Centralised here so OverviewTab, NovaSidebar, and future AI integrations
// all share the same logic — swap getNovaResponse() for an API call and
// nothing else in the codebase needs to change.

import { fmt } from '../utils/format';
import { NOVA_TAGLINES } from '../utils/constants';

export const INSIGHT_TYPES = {
  URGENT:   'urgent',
  WARNING:  'warning',
  WIN:      'win',
  ADVICE:   'advice',
  INFO:     'info',
  PROGRESS: 'progress',
};

function daysLeftInWeek() {
  const day = new Date().getDay();
  return day === 0 ? 0 : 7 - day;
}

function nextQuarterDeadline() {
  const now = new Date();
  const deadlines = [
    new Date(now.getFullYear(), 3, 15),
    new Date(now.getFullYear(), 5, 15),
    new Date(now.getFullYear(), 8, 15),
    new Date(now.getFullYear() + 1, 0, 15),
  ];
  return deadlines.find(d => d > now);
}

// ── Main insight generator ────────────────────────────────────────────────────
export function generateInsights(context) {
  const {
    totalCash, totalDebt, totalBudget, totalSavings,
    netWorth, weekEarned, weeklyGoal, runwayDays, upcomingDues,
    goals, incLog, taxRate, userType, config,
  } = context;

  const insights    = [];
  const weekPct     = weeklyGoal > 0 ? (weekEarned / weeklyGoal) * 100 : 0;
  const daysLeft    = daysLeftInWeek();
  const dailyNeeded = daysLeft > 0 ? Math.max(0, weeklyGoal - weekEarned) / daysLeft : 0;
  const months      = totalBudget > 0 ? totalCash / totalBudget : 0;
  const today       = new Date().getDay();
  const ytd         = incLog?.reduce((a, b) => a + b.amount, 0) || 0;

  // Upcoming bill
  if (upcomingDues?.length > 0) {
    const due = upcomingDues[0];
    insights.push({
      type: due.daysUntil === 0 ? INSIGHT_TYPES.URGENT : INSIGHT_TYPES.WARNING,
      icon: '🔔',
      title: `${due.name} due ${due.daysUntil === 0 ? 'TODAY' : `in ${due.daysUntil}d`}`,
      body: `${fmt(due.monthly)} due on the ${due.dueDay}th. ${totalCash >= due.monthly ? "You're covered." : `You're ${fmt(due.monthly - totalCash)} short.`}`,
      color: due.daysUntil === 0 ? '#ef4444' : '#f59e0b', priority: 10,
    });
  }

  // Critical runway
  if (runwayDays < 7) {
    insights.push({
      type: INSIGHT_TYPES.URGENT, icon: '⚠️', title: 'Low cash runway',
      body: `${Math.floor(runwayDays)} days of cash remaining. Income is the priority right now — everything else waits.`,
      color: '#ef4444', priority: 9,
    });
  }

  // Weekly goal
  if (weeklyGoal > 0) {
    if (weekPct >= 100) {
      const extra = weekEarned - weeklyGoal;
      const high  = config?.debts?.filter(d => d.apr >= 20).sort((a, b) => b.apr - a.apr)[0];
      insights.push({
        type: INSIGHT_TYPES.WIN, icon: '🎉', title: 'Weekly goal hit!',
        body: `${fmt(weekEarned)} earned — ${fmt(extra)} above goal.${high ? ` Put that extra toward ${high.name} (${high.apr}% APR).` : ''}`,
        color: '#10b981', priority: 7,
      });
    } else if (weekPct < 50 && today >= 4) {
      insights.push({
        type: INSIGHT_TYPES.WARNING, icon: '⚡', title: 'Behind on weekly goal',
        body: `${fmt(weekEarned)} of ${fmt(weeklyGoal)} with ${daysLeft} day${daysLeft === 1 ? '' : 's'} left. Need ${fmt(dailyNeeded)}/day.`,
        color: '#f59e0b', priority: 8,
      });
    } else if (weekPct >= 50 && weekPct < 100 && daysLeft > 0) {
      insights.push({
        type: INSIGHT_TYPES.PROGRESS, icon: '📈', title: `${Math.round(weekPct)}% of weekly goal`,
        body: `${fmt(weekEarned)} earned. ${fmt(dailyNeeded)}/day for ${daysLeft} more day${daysLeft === 1 ? '' : 's'}.`,
        color: '#3b82f6', priority: 5,
      });
    }
  }

  // Short runway warning
  if (runwayDays >= 7 && runwayDays < 14) {
    insights.push({
      type: INSIGHT_TYPES.WARNING, icon: '🕐', title: '2-week runway',
      body: `${Math.floor(runwayDays)} days of cash. Target is 30+ for real breathing room.`,
      color: '#f59e0b', priority: 6,
    });
  }

  // Bill forecast warning
  if (months > 0 && months < 1 && totalBudget > 0) {
    insights.push({
      type: INSIGHT_TYPES.WARNING, icon: '📅', title: 'Less than 1 month of bills covered',
      body: `${fmt(totalCash)} covers ${(months * 30).toFixed(0)} days of expenses. Build toward ${fmt(totalBudget * 3)}.`,
      color: '#f59e0b', priority: 7,
    });
  }

  // Healthy runway milestone
  if (months >= 3 && months < 6 && totalBudget > 0) {
    insights.push({
      type: INSIGHT_TYPES.WIN, icon: '🛡️', title: '3-month emergency fund reached',
      body: `${fmt(totalCash)} covers ${months.toFixed(1)} months. Solid foundation. Next: 6 months.`,
      color: '#10b981', priority: 4,
    });
  }

  // High-APR debt advice when above goal
  if (config?.debts?.length > 0 && weekEarned > weeklyGoal && weeklyGoal > 0) {
    const high = config.debts.filter(d => d.apr >= 20 && (d.balance || 0) > 0).sort((a, b) => b.apr - a.apr)[0];
    if (high) {
      insights.push({
        type: INSIGHT_TYPES.ADVICE, icon: '💡', title: `You're above goal — attack ${high.name}`,
        body: `At ${high.apr}% APR, every extra dollar on ${high.name} is a guaranteed return. Even ${fmt(50)} extra saves you money immediately.`,
        color: '#a78bfa', priority: 5,
      });
    }
  }

  // Savings milestone
  if (totalSavings > 0 && totalBudget > 0 && totalSavings >= totalBudget * 3) {
    insights.push({
      type: INSIGHT_TYPES.WIN, icon: '🏦', title: '3-month savings goal reached',
      body: `${fmt(totalSavings)} in savings. Consider opening a Roth IRA — $7,000/year, tax-free forever.`,
      color: '#10b981', priority: 3,
    });
  }

  // Quarterly tax warning
  if ((userType === 'gig' || userType === 'individual') && ytd > 0) {
    const nextQ = nextQuarterDeadline();
    if (nextQ) {
      const daysToQ = Math.ceil((nextQ - new Date()) / (1000 * 60 * 60 * 24));
      if (daysToQ <= 30) {
        insights.push({
          type: INSIGHT_TYPES.WARNING, icon: '🧾', title: `Quarterly tax due in ${daysToQ} days`,
          body: `Based on ${fmt(ytd)} earned, set aside ~${fmt((ytd * ((taxRate || 25) / 100)) / 4)} for this quarter.`,
          color: '#f59e0b', priority: 8,
        });
      }
    }
  }

  // Goal nearing completion
  const nearDone = goals?.find(g => g.target > 0 && g.saved > 0 && (g.saved / g.target) >= 0.8 && g.saved < g.target);
  if (nearDone) {
    insights.push({
      type: INSIGHT_TYPES.WIN, icon: nearDone.icon || '🎯', title: `${nearDone.name} is 80% funded`,
      body: `Only ${fmt(nearDone.target - nearDone.saved)} to go. You're almost there.`,
      color: '#10b981', priority: 4,
    });
  }

  // No income logged
  if (weeklyGoal > 0 && weekEarned === 0 && daysLeft < 5) {
    insights.push({
      type: INSIGHT_TYPES.WARNING, icon: '💵', title: 'No income logged this week',
      body: `Your weekly goal is ${fmt(weeklyGoal)}. Log income as you earn to stay accurate.`,
      color: '#f59e0b', priority: 6,
    });
  }

  return insights.sort((a, b) => b.priority - a.priority).slice(0, 4);
}

// ── Greeting by time of day + user type ───────────────────────────────────────
export function getNovaGreeting(name, userType) {
  const h = new Date().getHours();
  const time = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const tagline = NOVA_TAGLINES?.[userType] || "Let's get your money working for you.";
  return `${time}${name ? `, ${name}` : ''}. ${tagline}`;
}

// ── Conversational response for Nova sidebar ──────────────────────────────────
export function getNovaResponse(message, context) {
  const msg = message.toLowerCase().trim();
  const { totalCash, totalDebt, weekEarned, weeklyGoal, runwayDays,
          totalBudget, netWorth, userType, config, incLog, totalSavings } = context;

  const months  = totalBudget > 0 ? totalCash / totalBudget : 0;
  const weekPct = weeklyGoal > 0 ? (weekEarned / weeklyGoal) * 100 : 0;
  const ytd     = incLog?.reduce((a, b) => a + b.amount, 0) || 0;

  if (msg.includes('debt') || msg.includes('owe') || msg.includes('credit')) {
    const high = config?.debts?.filter(d => d.apr >= 20).sort((a, b) => b.apr - a.apr)[0];
    if (high) return `Your highest-APR debt is ${high.name} at ${high.apr}% — costing ~${fmt(high.balance * high.apr / 100 / 12)}/month in interest.\n\nThe move: minimums on everything else, every extra dollar at ${high.name}. Avalanche method — mathematically fastest.`;
    return `Total debt is ${fmt(totalDebt)}. Start with the highest APR — that's the one costing you the most. Check your Debts tab.`;
  }
  if (msg.includes('goal') || msg.includes('week') || msg.includes('income')) {
    if (weekPct >= 100) return `Weekly goal hit — ${fmt(weekEarned)} earned! 🎉 Put any extra toward your highest-APR debt.`;
    const rem = Math.max(0, weeklyGoal - weekEarned);
    const dl  = daysLeftInWeek();
    return `${fmt(weekEarned)} of ${fmt(weeklyGoal)} this week, ${dl} day${dl !== 1 ? 's' : ''} left. Need ${fmt(dl > 0 ? rem / dl : rem)}/day to hit goal.`;
  }
  if (msg.includes('sav') || msg.includes('emergency') || msg.includes('fund')) {
    if (months < 1)  return `Less than a month of expenses saved — first priority. Even $20/week builds the buffer.`;
    if (months < 3)  return `${months.toFixed(1)} months saved. Target is 3 months — ${fmt(Math.max(0, (3 - months) * totalBudget))} to go.`;
    return `${months.toFixed(1)} months covered. Solid. Next: Roth IRA — $7k/year, tax-free growth.`;
  }
  if (msg.includes('tax') || msg.includes('quarterly')) {
    return `Based on ${fmt(ytd)} earned:\n• SE tax (15.3%): ${fmt(ytd * 0.153)}\n• Income tax est: ${fmt(ytd * 0.22)}\n• Total est: ${fmt(ytd * 0.373)}\n\nMileage + business expenses reduce that. Check Tax tab.`;
  }
  if (msg.includes('mile') || msg.includes('deduct')) {
    return `Mileage deduction is $0.67/mile (2024). 200mi/week = ${fmt(200 * 0.67 * 52)}/year off your taxable income. Log every work trip in Mileage tab.`;
  }
  if (msg.includes('stress') || msg.includes('worried') || msg.includes('behind')) {
    return `That's real. The fact that you're tracking this puts you ahead of most people.\n\nWhat specifically feels hardest right now? Let's look at it together.`;
  }
  if (msg.includes('help') || msg === '') {
    return `Ask me anything:\n\n• "How do I pay off debt faster?"\n• "Am I on track this week?"\n• "What's my tax estimate?"\n• "How's my runway?"\n• "What should I focus on?"\n\nWhat's on your mind?`;
  }
  // Default snapshot
  const high = config?.debts?.sort((a, b) => b.apr - a.apr)[0];
  return `Snapshot:\n📊 Net worth: ${fmt(netWorth)}\n💵 Cash: ${fmt(totalCash)} (${Math.floor(runwayDays)}d runway)\n🎯 Week: ${fmt(weekEarned)} / ${fmt(weeklyGoal)} (${Math.round(weekPct)}%)${high ? `\n💳 Priority: ${high.name} @ ${high.apr}% APR` : ''}\n\nWhat would you like to dig into?`;
}
